package com.payilagam.enoolagam;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.payilagam.enoolagam.model.BookModel;
import com.squareup.picasso.Picasso;

import java.util.List;

public class BookAdapter extends RecyclerView.Adapter<BookAdapter.BookViewHolder> {

    private List<BookModel> bookList;
    private Context context;
    private OnBookClickListener listener;

    // Constructor
    public BookAdapter(Context context, List<BookModel> bookList, OnBookClickListener onBookClickListener) {
        this.context = context;
        this.bookList = bookList;
        this.listener = onBookClickListener;
    }

    // Interface for click actions
    public interface OnBookClickListener {
        void onBookClick(BookModel book);
    }

    // ViewHolder: Holds item layout
    public static class BookViewHolder extends RecyclerView.ViewHolder {
        ImageView bookImage;
        TextView bookName, bookLikes, bookPages, bookCategory;

        public BookViewHolder(View itemView) {
            super(itemView);
            bookImage = itemView.findViewById(R.id.bookImage);
            bookName = itemView.findViewById(R.id.bookName);
            bookLikes = itemView.findViewById(R.id.bookLikes);
            bookPages = itemView.findViewById(R.id.bookPages);
            bookCategory = itemView.findViewById(R.id.bookCategory); // Add this TextView in XML
        }
    }

    @Override
    public BookViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.book_card, parent, false);
        return new BookViewHolder(view);
    }

    @Override
    public void onBindViewHolder(BookViewHolder holder, int position) {
        BookModel book = bookList.get(position);

        holder.bookName.setText(book.getBookName());
        holder.bookLikes.setText("Likes: " + book.getLikes());
        holder.bookPages.setText("Pages: " + book.getTotalPages());
        holder.bookCategory.setText("Category: " + book.getCategory());

        Picasso.get()
                .load(book.getBookCover())
                .placeholder(R.drawable.book_cover) // fallback image
                .error(R.drawable.book_cover)       // fallback if URL fails
                .into(holder.bookImage);

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onBookClick(book);
            }
        });
    }

    @Override
    public int getItemCount() {
        return bookList.size();
    }

    // Update list on filter
    public void updateList(List<BookModel> newList) {
        this.bookList = newList;
        notifyDataSetChanged();
    }
}
