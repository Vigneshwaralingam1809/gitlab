package com.payilagam.enoolagam;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.NavigationUI;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        if(AuthManager.isAuthenticated(this)){
            setContentView(R.layout.activity_main);
        }
        else{
            Intent loginIndent = new Intent(MainActivity.this, LoginActivity.class);
            startActivity(loginIndent);
            finish();
        }

        BottomNavigationView bottomNav = findViewById(R.id.bottomNavigationView);

        // navigation manager for changes: activity_main.xml, nav_graph.xml, bottom_tab.xml.
        NavHostFragment navHostFragment = (NavHostFragment)
                getSupportFragmentManager().findFragmentById(R.id.nav_host_fragment);
        if (navHostFragment != null) {
            NavController navController = navHostFragment.getNavController();
            NavigationUI.setupWithNavController(bottomNav, navController);
        }

        
    }
}
