package com.payilagam.enoolagam;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.payilagam.enoolagam.model.HistoryModel;

import java.util.List;

public class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.HistoryViewHolder> {

    private List<HistoryModel> historyList;
    private Context context;

    public HistoryAdapter(Context context, List<HistoryModel> historyList) {
        this.context = context;
        this.historyList = historyList;
    }

    @Override
    public HistoryViewHolder onCreateViewHolder(ViewGroup parent, int ViewType){
        View view = LayoutInflater.from(context).inflate(R.layout.history_card, parent, false);
        return new HistoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(HistoryViewHolder holder, int position){
        HistoryModel historyCard = historyList.get(position);
        holder.bookName.setText(historyCard.getBookName());
        holder.bookImage.setImageResource(historyCard.getBookCover());
        holder.bookPages.setText(historyCard.getTotalPages()+"");
    }
    @Override
    public int getItemCount(){
        return historyList.size();
    }
    
    public static class HistoryViewHolder extends RecyclerView.ViewHolder{
        ImageView bookImage;
        TextView bookName, author, bookPages;
        public HistoryViewHolder(View individualCard){
            super(individualCard);
            bookName = individualCard.findViewById(R.id.historyBookName);
            author = individualCard.findViewById(R.id.historyBookAuthor);
            bookPages = individualCard.findViewById(R.id.historyBookPages);
            bookImage = itemView.findViewById(R.id.historyBookImage);
        }
    }

}
