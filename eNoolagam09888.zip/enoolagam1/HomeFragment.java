package com.payilagam.enoolagam;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.LinearSnapHelper;
import androidx.recyclerview.widget.SnapHelper;

import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.payilagam.enoolagam.model.BookModel;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class HomeFragment extends Fragment {

    // UI elements
    private TextView welcomeText;
    private ChipGroup chipGroup;

    // RecyclerViews and their Adapters (all are now properly declared as member variables)
    private TextView categoryTitleAll, categoryTitleHorror, categoryTitleRomance, categoryTitleOthers;
    private RecyclerView bookRecyclerViewAll, bookRecyclerViewHorror, bookRecyclerViewRomance, bookRecyclerViewOthers;
    private BookAdapter adapterAll, adapterHorror, adapterRomance, adapterOthers; // Separate adapters for each RV

    // Full list of all books
    private List<BookModel> fullBookList = new ArrayList<>();

    // Categorized lists for easy filtering (populated once)
    private List<BookModel> horrorBooks = new ArrayList<>();
    private List<BookModel> romanceBooks = new ArrayList<>();
    private List<BookModel> otherBooks = new ArrayList<>();

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        // 1️⃣ Welcome TextView setup
        welcomeText = view.findViewById(R.id.welcomeText);
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("user_pref", Context.MODE_PRIVATE);
        String username = sharedPreferences.getString("username", "Guest");
        if (username.contains("@")) {
            username = username.substring(0, username.indexOf('@'));
        }
        welcomeText.setText("Welcome to Enool0gam, " + username + "! 👋");

        // 2️⃣ Initialize Category Titles
        categoryTitleAll = view.findViewById(R.id.categoryTitleAll);
        categoryTitleHorror = view.findViewById(R.id.categoryTitleHorror);
        categoryTitleRomance = view.findViewById(R.id.categoryTitleRomance);
        categoryTitleOthers = view.findViewById(R.id.categoryTitleOthers);

        // 3️⃣ Initialize RecyclerViews
        bookRecyclerViewAll = view.findViewById(R.id.bookRecyclerViewAll);
        bookRecyclerViewHorror = view.findViewById(R.id.bookRecyclerViewHorror);
        bookRecyclerViewRomance = view.findViewById(R.id.bookRecyclerViewRomance);
        bookRecyclerViewOthers = view.findViewById(R.id.bookRecyclerViewOthers);

        // 4️⃣ Set up LayoutManagers and Adapters for each RecyclerView
        // Each RecyclerView gets its OWN adapter instance
        // Corrected: Using getBookName() and updateList()
        adapterAll = new BookAdapter(getContext(), new ArrayList<>(), book -> Toast.makeText(getContext(), "Clicked: " + book.getBookName(), Toast.LENGTH_SHORT).show());
        adapterHorror = new BookAdapter(getContext(), new ArrayList<>(), book -> Toast.makeText(getContext(), "Clicked: " + book.getBookName(), Toast.LENGTH_SHORT).show());
        adapterRomance = new BookAdapter(getContext(), new ArrayList<>(), book -> Toast.makeText(getContext(), "Clicked: " + book.getBookName(), Toast.LENGTH_SHORT).show());
        adapterOthers = new BookAdapter(getContext(), new ArrayList<>(), book -> Toast.makeText(getContext(), "Clicked: " + book.getBookName(), Toast.LENGTH_SHORT).show());

        setupRecyclerView(bookRecyclerViewAll, adapterAll);
        setupRecyclerView(bookRecyclerViewHorror, adapterHorror);
        setupRecyclerView(bookRecyclerViewRomance, adapterRomance);
        setupRecyclerView(bookRecyclerViewOthers, adapterOthers);

        // 5️⃣ Setup Dummy Books and Categorize Them (done once)
        setupDummyBooksAndCategories();

        // 6️⃣ ChipGroup setup
        chipGroup = view.findViewById(R.id.chipGroup);
        chipGroup.setOnCheckedStateChangeListener((group, checkedIds) -> { // Use setOnCheckedStateChangeListener for MaterialComponents
            if (!checkedIds.isEmpty()) {
                Chip selectedChip = group.findViewById(checkedIds.get(0));
                if (selectedChip != null) {
                    String category = selectedChip.getText().toString();
                    filterBooks(category);
                }
            } else {
                filterBooks("All"); // Default to showing all categories if no chip is selected
            }
        });

        // 7️⃣ Initial filter (show "All" categories on startup)
        filterBooks("All");

        return view;
    }

    /**
     * Helper method to set up a RecyclerView with horizontal layout and SnapHelper.
     */
    private void setupRecyclerView(RecyclerView recyclerView, BookAdapter adapter) {
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));
        recyclerView.setAdapter(adapter);

        // Add SnapHelper for smooth snapping (optional)
        if (recyclerView.getOnFlingListener() == null) { // Prevent multiple attachments
            SnapHelper snapHelper = new LinearSnapHelper();
            snapHelper.attachToRecyclerView(recyclerView);
        }
    }

    /**
     * Populates fullBookList and then categorizes them into separate lists.
     * This method is called only once during fragment creation.
     */
    private void setupDummyBooksAndCategories() {
        // Clear previous data to avoid duplicates on orientation change/fragment re-creation
        fullBookList.clear();
        horrorBooks.clear();
        romanceBooks.clear();
        otherBooks.clear();

        // Add dummy books to fullBookList
        fullBookList.add(new BookModel("Author H1", "Scary Night 1", 120, 90, "https://example.com/horror1.jpg", "Horror"));
        fullBookList.add(new BookModel("Author H2", "Mystery Hill 2", 150, 80, "https://example.com/horror2.jpg", "Horror"));
        fullBookList.add(new BookModel("Author H3", "Haunted House 3", 130, 70, "https://example.com/horror3.jpg", "Horror"));
        fullBookList.add(new BookModel("Author H4", "Dark Forest 4", 140, 75, "https://example.com/horror4.jpg", "Horror"));
        fullBookList.add(new BookModel("Author H5", "Creepy Doll 5", 110, 65, "https://example.com/horror5.jpg", "Horror"));
        fullBookList.add(new BookModel("Author H6", "Zombie Apocalypse 6", 160, 95, "https://example.com/horror6.jpg", "Horror"));
        fullBookList.add(new BookModel("Author H7", "Vampire's Kiss 7", 170, 100, "https://example.com/horror7.jpg", "Horror"));
        fullBookList.add(new BookModel("Author H8", "Ghost Story 8", 125, 68, "https://example.com/horror8.jpg", "Horror"));


        fullBookList.add(new BookModel("Author R1", "Romantic Escape 1", 200, 130, "https://example.com/romance1.jpg", "Romance"));
        fullBookList.add(new BookModel("Author R2", "Love Letters 2", 170, 110, "https://example.com/romance2.jpg", "Romance"));
        fullBookList.add(new BookModel("Author R3", "First Date 3", 160, 100, "https://example.com/romance3.jpg", "Romance"));
        fullBookList.add(new BookModel("Author R4", "Eternal Embrace 4", 180, 120, "https://example.com/romance4.jpg", "Romance"));
        fullBookList.add(new BookModel("Author R5", "Star-Crossed 5", 190, 125, "https://example.com/romance5.jpg", "Romance"));
        fullBookList.add(new BookModel("Author R6", "Sweet Serenade 6", 155, 98, "https://example.com/romance6.jpg", "Romance"));
        fullBookList.add(new BookModel("Author R7", "Moonlit Dance 7", 165, 105, "https://example.com/romance7.jpg", "Romance"));


        fullBookList.add(new BookModel("Author O1", "Generic Book 1", 100, 60, "https://example.com/book1.jpg", "Others"));
        fullBookList.add(new BookModel("Author O2", "Fantasy Realm 2", 140, 85, "https://example.com/book2.jpg", "Others"));
        fullBookList.add(new BookModel("Author O3", "Sci-Fi Saga 3", 180, 115, "https://example.com/book3.jpg", "Others"));
        fullBookList.add(new BookModel("Author O4", "Adventure Quest 4", 135, 78, "https://example.com/book4.jpg", "Others"));


        // Categorize books using Java 8 Streams for efficiency
        horrorBooks.addAll(fullBookList.stream()
                .filter(book -> book.getCategory().equalsIgnoreCase("Horror"))
                .collect(Collectors.toList()));

        romanceBooks.addAll(fullBookList.stream()
                .filter(book -> book.getCategory().equalsIgnoreCase("Romance"))
                .collect(Collectors.toList()));

        otherBooks.addAll(fullBookList.stream()
                .filter(book -> book.getCategory().equalsIgnoreCase("Others"))
                .collect(Collectors.toList()));
    }

    /**
     * Filters the displayed RecyclerViews based on the selected category.
     * Manages visibility and data for each hardcoded RecyclerView.
     */
    private void filterBooks(String category) {
        // Hide all category titles and RecyclerViews initially
        categoryTitleAll.setVisibility(View.GONE);
        bookRecyclerViewAll.setVisibility(View.GONE);
        categoryTitleHorror.setVisibility(View.GONE);
        bookRecyclerViewHorror.setVisibility(View.GONE);
        categoryTitleRomance.setVisibility(View.GONE);
        bookRecyclerViewRomance.setVisibility(View.GONE);
        categoryTitleOthers.setVisibility(View.GONE);
        bookRecyclerViewOthers.setVisibility(View.GONE);


        if (category.equalsIgnoreCase("All")) {
            // Show all categories
            categoryTitleAll.setText("All Books");
            categoryTitleAll.setVisibility(View.VISIBLE);
            bookRecyclerViewAll.setVisibility(View.VISIBLE);
            adapterAll.updateList(fullBookList); // Corrected: Using updateList()

            categoryTitleHorror.setText("Horror Books");
            categoryTitleHorror.setVisibility(View.VISIBLE);
            bookRecyclerViewHorror.setVisibility(View.VISIBLE);
            adapterHorror.updateList(horrorBooks); // Corrected: Using updateList()

            categoryTitleRomance.setText("Romance Books");
            categoryTitleRomance.setVisibility(View.VISIBLE);
            bookRecyclerViewRomance.setVisibility(View.VISIBLE);
            adapterRomance.updateList(romanceBooks); // Corrected: Using updateList()

            categoryTitleOthers.setText("Other Books");
            categoryTitleOthers.setVisibility(View.VISIBLE);
            bookRecyclerViewOthers.setVisibility(View.VISIBLE);
            adapterOthers.updateList(otherBooks); // Corrected: Using updateList()

        } else if (category.equalsIgnoreCase("Horror")) {
            categoryTitleHorror.setText("Horror Books");
            categoryTitleHorror.setVisibility(View.VISIBLE);
            bookRecyclerViewHorror.setVisibility(View.VISIBLE);
            adapterHorror.updateList(horrorBooks); // Corrected: Using updateList()

        } else if (category.equalsIgnoreCase("Romance")) {
            categoryTitleRomance.setText("Romance Books");
            categoryTitleRomance.setVisibility(View.VISIBLE);
            bookRecyclerViewRomance.setVisibility(View.VISIBLE);
            adapterRomance.updateList(romanceBooks); // Corrected: Using updateList()

        } else if (category.equalsIgnoreCase("Others")) { // Added handling for "Others" chip
            categoryTitleOthers.setText("Other Books");
            categoryTitleOthers.setVisibility(View.VISIBLE);
            bookRecyclerViewOthers.setVisibility(View.VISIBLE);
            adapterOthers.updateList(otherBooks); // Corrected: Using updateList()
        } else {
            Toast.makeText(getContext(), "Category not found: " + category, Toast.LENGTH_SHORT).show();
        }
    }
}
