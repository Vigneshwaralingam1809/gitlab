package com.payilagam.enoolagam;

import android.content.Context;
import android.util.Log;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.payilagam.enoolagam.model.BookModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class BookModelView extends ViewModel {

    private boolean loaded = false;
    private MutableLiveData<List<BookModel>> booksLiveData = new MutableLiveData<>();

    public LiveData<List<BookModel>> getBooks() {
        return booksLiveData;
    }

    public void loadBooks(Context context, String url) {
        if (loaded) return;
        loaded = true;

        RequestQueue networkQueue = Volley.newRequestQueue(context);

        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(
                Request.Method.GET,
                url,
                null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        try {
                            List<BookModel> books = new ArrayList<>();

                            for (int i = 0; i < response.length(); i++) {
                                JSONObject individualBook = response.getJSONObject(i);

                                // ✅ Expecting the JSON to contain: "author", "title", "image", "category"
                                books.add(new BookModel(
                                        individualBook.getString("author"),
                                        individualBook.getString("title"),
                                        121, // You can update this with actual data if available
                                        120, // Same here for likes
                                        individualBook.getString("image"),
                                        individualBook.getString("category") // ✅ Added category
                                ));

                                Log.d("BookModelView", "Loaded book #" + i);
                            }

                            booksLiveData.postValue(books);
                        } catch (JSONException e) {
                            e.printStackTrace();
                            booksLiveData.postValue(new ArrayList<>()); // Send empty list on error
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("BookModelView", "Failed to fetch books: " + error.getMessage());
                        booksLiveData.postValue(new ArrayList<>());
                    }
                }
        );

        networkQueue.add(jsonArrayRequest);
    }
}
