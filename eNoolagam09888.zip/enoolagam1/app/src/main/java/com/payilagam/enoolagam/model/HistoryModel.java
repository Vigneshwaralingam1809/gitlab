package com.payilagam.enoolagam.model;

public class HistoryModel {
    private String bookName;
    private String author;
    private int bookCover;

    public int getBookCover() {
        return bookCover;
    }

    public HistoryModel(String bookName, String author, int totalPages, int bookCover) {
        this.bookName = bookName;
        this.author = author;
        this.totalPages = totalPages;
        this.bookCover = bookCover;
    }

    public void setBookCover(int bookCover) {
        this.bookCover = bookCover;
    }

    public String getBookName() {
        return bookName;
    }

    public void setBookName(String bookName) {
        this.bookName = bookName;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public int getTotalPages() {
        return totalPages;
    }

    public void setTotalPages(int totalPages) {
        this.totalPages = totalPages;
    }

    private int totalPages;

    public HistoryModel(String bookName, String author, int totalPages) {
        this.bookName = bookName;
        this.author = author;
        this.totalPages = totalPages;
    }
}
