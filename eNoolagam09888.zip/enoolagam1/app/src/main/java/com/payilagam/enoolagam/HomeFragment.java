package com.payilagam.enoolagam;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;
import com.payilagam.enoolagam.model.BookModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class HomeFragment extends Fragment {

    // UI elements
    private TextView welcomeText;
    private ChipGroup chipGroup;
    private ViewPager2 bannerViewPager;
    private TabLayout bannerTabLayout;

    // A map to hold all dynamically created category views and their data
    private Map<String, CategoryView> categoryViews = new HashMap<>();

    // Full list of all books (from API)
    private List<BookModel> fullBookList = new ArrayList<>();

    // For auto-scrolling banner
    private Handler sliderHandler = new Handler(Looper.getMainLooper());
    private Runnable sliderRunnable;

    private static final String SUPABASE_URL = "https://jcrpcmsmuiayfkqmwklo.supabase.co/rest/v1/books";
    private static final String SUPABASE_API_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImpjcnBjbXNtdWlheWZrcW13a2xvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTQzNzMxNjIsImV4cCI6MjA2OTk0OTE2Mn0.i2p83riYpQ2IaxkIUnUEqlK6qDVpcuVCdEeAmqqn01o";

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // The layout file for this fragment is fragment_home.xml, not main_activity.xml
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        // 1️⃣ Welcome TextView setup
        welcomeText = view.findViewById(R.id.welcomeText);
        SharedPreferences sharedPreferences = requireActivity().getSharedPreferences("user_pref", Context.MODE_PRIVATE);
        String username = sharedPreferences.getString("username", "Guest");
        if (username != null && username.contains("@")) {
            username = username.substring(0, username.indexOf('@'));
        }
        welcomeText.setText("Welcome to Enool0gam, " + username + "! 👋");

        // 2️⃣ Initialize Banner ViewPager and TabLayout
        bannerViewPager = view.findViewById(R.id.bannerViewPager);
        bannerTabLayout = view.findViewById(R.id.bannerTabLayout);
        setupBannerCarousel();

        // 3️⃣ Initialize the category views from the XML layout
        initializeCategoryViews(view);

        // 4️⃣ Fetch books from the Supabase API
        fetchBooks();

        // 5️⃣ ChipGroup setup
        chipGroup = view.findViewById(R.id.chipGroup);
        chipGroup.setOnCheckedStateChangeListener((group, checkedIds) -> {
            if (!checkedIds.isEmpty()) {
                Chip selectedChip = view.findViewById(checkedIds.get(0));
                if (selectedChip != null) {
                    String category = selectedChip.getText().toString();
                    filterBooks(category);
                }
            } else {
                filterBooks(getString(R.string.all));
            }
        });

        // Initially check the "All" chip
        chipGroup.check(R.id.chipAll);

        return view;
    }

    /**
     * Initializes all the UI elements for each category.
     * This is a hardcoded approach. For a dynamic approach, you would dynamically
     * create these views in Java after fetching categories from the API.
     * @param view The root view of the fragment.
     */
    private void initializeCategoryViews(View view) {
        // For 'All' books category
        categoryViews.put(getString(R.string.all), new CategoryView(
                view.findViewById(R.id.categoryTitleAll),
                view.findViewById(R.id.bookRecyclerViewAll),
                view.findViewById(R.id.btnViewAllAll),
                new BookAdapter(getContext(), new ArrayList<>(), book -> navigateToCategoryDetail(book.getCategory()))
        ));

        // For 'கட்டுரைகள்' category
        categoryViews.put(getString(R.string.katturaikal), new CategoryView(
                view.findViewById(R.id.categoryTitleKatturaikal),
                view.findViewById(R.id.bookRecyclerViewKatturaikal),
                view.findViewById(R.id.btnViewAllKatturaikal),
                new BookAdapter(getContext(), new ArrayList<>(), book -> navigateToCategoryDetail(book.getCategory()))
        ));

        // For 'சிறுகதைகள்' category
        categoryViews.put(getString(R.string.sirukathai), new CategoryView(
                view.findViewById(R.id.categoryTitleSirukathai),
                view.findViewById(R.id.bookRecyclerViewSirukathai),
                view.findViewById(R.id.btnViewAllSirukathai),
                new BookAdapter(getContext(), new ArrayList<>(), book -> navigateToCategoryDetail(book.getCategory()))
        ));

        // For 'புதினம்' category
        categoryViews.put(getString(R.string.puthinam), new CategoryView(
                view.findViewById(R.id.categoryTitlePuthinam),
                view.findViewById(R.id.bookRecyclerViewPuthinam),
                view.findViewById(R.id.btnViewAllPuthinam),
                new BookAdapter(getContext(), new ArrayList<>(), book -> navigateToCategoryDetail(book.getCategory()))
        ));

        // ADDED new categories you requested:
        // For 'ஆன்மிகம்' category
        categoryViews.put(getString(R.string.anmikam), new CategoryView(
                view.findViewById(R.id.categoryTitleAnmikam),
                view.findViewById(R.id.bookRecyclerViewAnmikam),
                view.findViewById(R.id.btnViewAllAnmikam),
                new BookAdapter(getContext(), new ArrayList<>(), book -> navigateToCategoryDetail(book.getCategory()))
        ));

        // For 'குறுந்தகவல்கள்' category
        categoryViews.put(getString(R.string.kurumbathivu), new CategoryView(
                view.findViewById(R.id.categoryTitleKurumbathivu),
                view.findViewById(R.id.bookRecyclerViewKurumbathivu),
                view.findViewById(R.id.btnViewAllKurumbathivu),
                new BookAdapter(getContext(), new ArrayList<>(), book -> navigateToCategoryDetail(book.getCategory()))
        ));

        // For 'நாவல்' category
        categoryViews.put(getString(R.string.naval), new CategoryView(
                view.findViewById(R.id.categoryTitleNaval),
                view.findViewById(R.id.bookRecyclerViewNaval),
                view.findViewById(R.id.btnViewAllNaval),
                new BookAdapter(getContext(), new ArrayList<>(), book -> navigateToCategoryDetail(book.getCategory()))
        ));

        // For 'அறிவியல்' category
        categoryViews.put(getString(R.string.ariviyal), new CategoryView(
                view.findViewById(R.id.categoryTitleAriviyal),
                view.findViewById(R.id.bookRecyclerViewAriviyal),
                view.findViewById(R.id.btnViewAllAriviyal),
                new BookAdapter(getContext(), new ArrayList<>(), book -> navigateToCategoryDetail(book.getCategory()))
        ));

        // For 'இதழ்' category
        categoryViews.put(getString(R.string.ithal), new CategoryView(
                view.findViewById(R.id.categoryTitleIthal),
                view.findViewById(R.id.bookRecyclerViewIthal),
                view.findViewById(R.id.btnViewAllIthal),
                new BookAdapter(getContext(), new ArrayList<>(), book -> navigateToCategoryDetail(book.getCategory()))
        ));

        // For 'சொற்பொழிவு' category
        categoryViews.put(getString(R.string.sorpolivu), new CategoryView(
                view.findViewById(R.id.categoryTitleSorpolivu),
                view.findViewById(R.id.bookRecyclerViewSorpolivu),
                view.findViewById(R.id.btnViewAllSorpolivu),
                new BookAdapter(getContext(), new ArrayList<>(), book -> navigateToCategoryDetail(book.getCategory()))
        ));

        // Set up the RecyclerView for each category
        for (Map.Entry<String, CategoryView> entry : categoryViews.entrySet()) {
            CategoryView categoryView = entry.getValue();
            if (categoryView.recyclerView != null && categoryView.adapter != null) {
                setupRecyclerView(categoryView.recyclerView, categoryView.adapter);
            }
            if (categoryView.viewAllButton != null) {
                // The 'All' button has a special case for its click listener
                if (!entry.getKey().equals(getString(R.string.all))) {
                    categoryView.viewAllButton.setOnClickListener(v -> navigateToCategoryDetail(entry.getKey()));
                } else {
                    // For the 'All' books category, we pass "All" to show all books
                    categoryView.viewAllButton.setOnClickListener(v -> navigateToCategoryDetail(getString(R.string.all)));
                }
            }
        }
    }

    private void fetchBooks() {
        OkHttpClient client = new OkHttpClient();

        Request request = new Request.Builder()
                .url(SUPABASE_URL)
                .addHeader("apikey", SUPABASE_API_KEY)
                .addHeader("Authorization", "Bearer " + SUPABASE_API_KEY)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                Log.e("HomeFragment", "Fetch failed", e);
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (!response.isSuccessful()) {
                    Log.e("HomeFragment", "Unexpected code: " + response);
                    return;
                }

                String json = response.body().string();
                try {
                    JSONArray jsonArray = new JSONArray(json);
                    List<BookModel> books = new ArrayList<>();
                    Map<String, List<BookModel>> categorizedBooks = new HashMap<>();

                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject obj = jsonArray.getJSONObject(i);

                        String author = obj.optString("author");
                        String title = obj.optString("title");
                        String category = obj.optString("category");
                        String image = obj.optString("image");
                        String epub = obj.optString("epub");

                        BookModel book = new BookModel(author, title, 0, 0, image, category);
                        books.add(book);

                        // Populate the categorized lists dynamically
                        if (!categorizedBooks.containsKey(category)) {
                            categorizedBooks.put(category, new ArrayList<>());
                        }
                        categorizedBooks.get(category).add(book);
                    }

                    requireActivity().runOnUiThread(() -> {
                        // Update the master list
                        fullBookList.clear();
                        fullBookList.addAll(books);

                        // Update all adapters based on the fetched data
                        if (categoryViews.get(getString(R.string.all)) != null) {
                            categoryViews.get(getString(R.string.all)).adapter.updateList(fullBookList);
                        }
                        for (Map.Entry<String, List<BookModel>> entry : categorizedBooks.entrySet()) {
                            CategoryView categoryView = categoryViews.get(entry.getKey());
                            if (categoryView != null && categoryView.adapter != null) {
                                categoryView.adapter.updateList(entry.getValue());
                            }
                        }

                        // Set visibility for all categories
                        filterBooks(getString(R.string.all));
                    });

                } catch (JSONException e) {
                    Log.e("HomeFragment", "JSON error", e);
                }
            }
        });
    }

    private void setupRecyclerView(RecyclerView recyclerView, BookAdapter adapter) {
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));
        recyclerView.setAdapter(adapter);
    }

    /**
     * Filters the books displayed based on the selected category chip.
     * @param category The name of the selected category.
     */
    private void filterBooks(String category) {
        // First, hide all category views to ensure clean state
        for (CategoryView categoryView : categoryViews.values()) {
            categoryView.title.setVisibility(View.GONE);
            categoryView.recyclerView.setVisibility(View.GONE);
            if (categoryView.viewAllButton != null) {
                categoryView.viewAllButton.setVisibility(View.GONE);
            }
        }

        if (category.equalsIgnoreCase(getString(R.string.all))) {
            // Show all categories
            for (Map.Entry<String, CategoryView> entry : categoryViews.entrySet()) {
                CategoryView categoryView = entry.getValue();
                categoryView.title.setVisibility(View.VISIBLE);
                categoryView.recyclerView.setVisibility(View.VISIBLE);
                // Only show the button if there are books in this category
                if (categoryView.adapter != null && categoryView.adapter.getItemCount() > 0) {
                    if (categoryView.viewAllButton != null) {
                        categoryView.viewAllButton.setVisibility(View.VISIBLE);
                    }
                }
            }
        } else {
            // Show only the selected category
            CategoryView selectedCategoryView = categoryViews.get(category);
            if (selectedCategoryView != null) {
                selectedCategoryView.title.setVisibility(View.VISIBLE);
                selectedCategoryView.recyclerView.setVisibility(View.VISIBLE);
                if (selectedCategoryView.adapter != null && selectedCategoryView.adapter.getItemCount() > 0) {
                    if (selectedCategoryView.viewAllButton != null) {
                        selectedCategoryView.viewAllButton.setVisibility(View.VISIBLE);
                    }
                }
            }
        }
    }

    private void setupBannerCarousel() {
        List<Integer> bannerImages = new ArrayList<>();
        bannerImages.add(R.drawable.banner1);
        bannerImages.add(R.drawable.banner2);
        bannerImages.add(R.drawable.banner3);

        BannerAdapter bannerAdapter = new BannerAdapter(bannerImages);
        bannerViewPager.setAdapter(bannerAdapter);

        new TabLayoutMediator(bannerTabLayout, bannerViewPager, (tab, position) -> {}).attach();

        sliderRunnable = () -> {
            if (bannerViewPager.getCurrentItem() == bannerImages.size() - 1) {
                bannerViewPager.setCurrentItem(0);
            } else {
                bannerViewPager.setCurrentItem(bannerViewPager.getCurrentItem() + 1);
            }
        };

        bannerViewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                sliderHandler.removeCallbacks(sliderRunnable);
                sliderHandler.postDelayed(sliderRunnable, 3000);
            }
        });

        sliderHandler.postDelayed(sliderRunnable, 3000);
    }

    private static class BannerAdapter extends RecyclerView.Adapter<BannerAdapter.BannerViewHolder> {
        private final List<Integer> images;

        public BannerAdapter(List<Integer> images) {
            this.images = images;
        }

        @NonNull
        @Override
        public BannerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            ImageView imageView = new ImageView(parent.getContext());
            imageView.setLayoutParams(new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT));
            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            return new BannerViewHolder(imageView);
        }

        @Override
        public void onBindViewHolder(@NonNull BannerAdapter.BannerViewHolder holder, int position) {
            holder.imageView.setImageResource(images.get(position));
        }

        @Override
        public int getItemCount() {
            return images.size();
        }

        static class BannerViewHolder extends RecyclerView.ViewHolder {
            ImageView imageView;

            public BannerViewHolder(@NonNull View itemView) {
                super(itemView);
                imageView = (ImageView) itemView;
            }
        }
    }

    /**
     * A helper class to group the UI elements for a single book category.
     * This makes the code cleaner and easier to manage.
     */
    private static class CategoryView {
        TextView title;
        RecyclerView recyclerView;
        ImageButton viewAllButton;
        BookAdapter adapter;

        public CategoryView(TextView title, RecyclerView recyclerView, ImageButton viewAllButton, BookAdapter adapter) {
            this.title = title;
            this.recyclerView = recyclerView;
            this.viewAllButton = viewAllButton;
            this.adapter = adapter;
        }
    }


    private void navigateToCategoryDetail(String category) {
        // Log the category name to ensure the correct value is being passed
        Log.d("HomeFragment", "Navigating to CategoryDetailActivity for category: " + category);
        Intent intent = new Intent(getContext(), com.payilagam.enoolagam.CategoryDetailActivity.class);
        intent.putExtra("CATEGORY_NAME", category);
        startActivity(intent);
    }

    @Override
    public void onPause() {
        super.onPause();
        sliderHandler.removeCallbacks(sliderRunnable);
    }

    @Override
    public void onResume() {
        super.onResume();
        if (sliderHandler != null) {
            sliderHandler.postDelayed(sliderRunnable, 3000);
        }
    }
}
