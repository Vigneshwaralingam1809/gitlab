package com.payilagam.enoolagam;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class VerifyEmailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verify_email);

        TextView message = findViewById(R.id.verificationMessage);
        message.setText("✅ Please check your email inbox and click the verification link to activate your account.");
    }
}
