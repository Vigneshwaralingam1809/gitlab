package com.payilagam.enoolagam.services;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class AuthManager {

    public interface AuthCallback {
        void onComplete(boolean success, String message);
    }

    private static final OkHttpClient client = new OkHttpClient();
    private static final MediaType JSON = MediaType.get("application/json; charset=utf-8");

    public static void registerWithSupabase(Context context, String email, String password, AuthCallback callback) {
        JSONObject json = new JSONObject();
        try {
            json.put("email", email);
            json.put("password", password);
        } catch (JSONException e) {
            callback.onComplete(false, "Invalid registration data");
            return;
        }

        RequestBody body = RequestBody.create(json.toString(), JSON);

        Request request = new Request.Builder()
                .url(SupabaseConfig.SUPABASE_URL + "/auth/v1/signup")
                .addHeader("apikey", SupabaseConfig.SUPABASE_API_KEY)
                .addHeader("Authorization", "Bearer " + SupabaseConfig.SUPABASE_API_KEY)
                .post(body)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                callback.onComplete(false, "Network Error");
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String resStr = response.body().string();
                if (response.isSuccessful()) {
                    callback.onComplete(true, "Registered successfully. Please verify your email.");
                } else {
                    callback.onComplete(false, "Registration failed: " + resStr);
                }
            }
        });
    }

    public static void loginWithSupabase(Context context, String email, String password, AuthCallback callback) {
        JSONObject json = new JSONObject();
        try {
            json.put("email", email);
            json.put("password", password);
        } catch (JSONException e) {
            callback.onComplete(false, "Invalid login data");
            return;
        }

        RequestBody body = RequestBody.create(json.toString(), JSON);

        Request request = new Request.Builder()
                .url(SupabaseConfig.SUPABASE_URL + "/auth/v1/token?grant_type=password")
                .addHeader("apikey", SupabaseConfig.SUPABASE_API_KEY)
                .addHeader("Authorization", "Bearer " + SupabaseConfig.SUPABASE_API_KEY)
                .post(body)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                callback.onComplete(false, "Network error");
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String resStr = response.body().string();
                if (response.isSuccessful()) {
                    saveToken(context, resStr);

                    try {
                        JSONObject obj = new JSONObject(resStr);
                        String accessToken = obj.getString("access_token");

                        Request verifyRequest = new Request.Builder()
                                .url(SupabaseConfig.SUPABASE_URL + "/auth/v1/user")
                                .addHeader("Authorization", "Bearer " + accessToken)
                                .addHeader("apikey", SupabaseConfig.SUPABASE_API_KEY)
                                .build();

                        client.newCall(verifyRequest).enqueue(new Callback() {
                            @Override
                            public void onFailure(Call call, IOException e) {
                                callback.onComplete(false, "Failed to verify email.");
                            }

                            @Override
                            public void onResponse(Call call, Response response) throws IOException {
                                String userJsonStr = response.body().string();
                                try {
                                    JSONObject userJson = new JSONObject(userJsonStr);
                                    if (!userJson.isNull("email_confirmed_at")) {
                                        callback.onComplete(true, "Login successful");
                                    } else {
                                        callback.onComplete(false, "Please verify your email before login.");
                                    }
                                } catch (JSONException e) {
                                    callback.onComplete(false, "Failed to parse verification info");
                                }
                            }
                        });

                    } catch (JSONException e) {
                        callback.onComplete(false, "Failed to parse login response");
                    }
                } else {
                    callback.onComplete(false, "Invalid credentials");
                }
            }
        });
    }

    public static void refreshSession(Context context, AuthCallback callback) {
        SharedPreferences preferences = context.getSharedPreferences("login_pref", Context.MODE_PRIVATE);
        String refreshToken = preferences.getString("refresh_token", null);

        if (refreshToken == null) {
            callback.onComplete(false, "No refresh token available");
            return;
        }

        JSONObject json = new JSONObject();
        try {
            json.put("refresh_token", refreshToken);
        } catch (JSONException e) {
            callback.onComplete(false, "Failed to create refresh request");
            return;
        }

        RequestBody body = RequestBody.create(json.toString(), JSON);
        Request request = new Request.Builder()
                .url(SupabaseConfig.SUPABASE_URL + "/auth/v1/token?grant_type=refresh_token")
                .addHeader("apikey", SupabaseConfig.SUPABASE_API_KEY)
                .addHeader("Authorization", "Bearer " + SupabaseConfig.SUPABASE_API_KEY)
                .post(body)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                callback.onComplete(false, "Network error during refresh");
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String resStr = response.body().string();
                if (response.isSuccessful()) {
                    saveToken(context, resStr);
                    callback.onComplete(true, "Session refreshed");
                } else {
                    callback.onComplete(false, "Failed to refresh session");
                }
            }
        });
    }

    public static void logout(Context context) {
        SharedPreferences preferences = context.getSharedPreferences("login_pref", Context.MODE_PRIVATE);
        preferences.edit().clear().apply();
    }

    public static boolean isAuthenticated(Context context) {
        SharedPreferences preferences = context.getSharedPreferences("login_pref", Context.MODE_PRIVATE);
        String token = preferences.getString("access_token", null);
        long expiresAt = preferences.getLong("expires_at", 0);
        long now = System.currentTimeMillis() / 1000;
        return token != null && !token.isEmpty() && now < expiresAt;
    }

    private static void saveToken(Context context, String json) {
        try {
            JSONObject obj = new JSONObject(json);
            String accessToken = obj.getString("access_token");
            String refreshToken = obj.getString("refresh_token");
            long expiresIn = obj.optLong("expires_in", 3600); // default 1 hour
            long expiresAt = (System.currentTimeMillis() / 1000) + expiresIn;

            SharedPreferences preferences = context.getSharedPreferences("login_pref", Context.MODE_PRIVATE);
            preferences.edit()
                    .putString("access_token", accessToken)
                    .putString("refresh_token", refreshToken)
                    .putLong("expires_at", expiresAt)
                    .apply();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
