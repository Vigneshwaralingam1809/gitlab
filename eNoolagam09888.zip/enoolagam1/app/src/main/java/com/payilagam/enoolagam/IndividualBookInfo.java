package com.payilagam.enoolagam;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.tabs.TabLayout;

public class IndividualBookInfo extends Fragment {

    public void onCreate(Bundle savedInstance) {
        super.onCreate(savedInstance);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        
        View view = inflater.inflate(R.layout.individual_book_info, container, false);
        // Initialize UI components as local variables.
        // This resolves the "Field can be local variable" warnings.
        ImageView bookCover = view.findViewById(R.id.bookCover);
        TextView bookTitle = view.findViewById(R.id.bookTitle);
        TextView authorName = view.findViewById(R.id.authorName);
        RatingBar ratingBar = view.findViewById(R.id.ratingBar);
        TextView ratingText = view.findViewById(R.id.ratingText);
        TextView pagesCount = view.findViewById(R.id.pagesCount);
        TextView fileSize = view.findViewById(R.id.fileSize);
        TextView language = view.findViewById(R.id.language);
        TabLayout tabLayout = view.findViewById(R.id.tabLayout);
        TextView descriptionText = view.findViewById(R.id.descriptionText);
        Button downloadButton = view.findViewById(R.id.downloadButton);
        Button readButton = view.findViewById(R.id.readButton);
        ImageButton backButton = view.findViewById(R.id.backButton);
        ImageButton shareButton = view.findViewById(R.id.shareButton);
        ImageButton moreButton = view.findViewById(R.id.moreButton);
        FloatingActionButton bookmarkFab = view.findViewById(R.id.bookmarkFab);

        // Populate with example data from strings.xml
        // Ensure 'book_cover' is correctly placed in drawable-xxxhdpi or similar
        bookCover.setImageResource(R.drawable.book_cover);
        bookTitle.setText("Sample");
        authorName.setText("Muthu");
        ratingBar.setRating(4.0f);
        ratingText.setText("Ratings");
        pagesCount.setText("278");
        fileSize.setText("1.5 Mb");
        language.setText("Tamizh");
        // Set initial description text
        descriptionText.setText("கல்கி கிருஷ்ணமூர்த்தியின் “அலை ஓசை” நாவல், இரு பெரும் பாகங்களாகப் பிரிந்து, இந்திய சுதந்திரப் போராட்ட காலத்தின் சமூக மற்றும் அரசியல் பின்னணியில், மனித உறவுகளின் ஆழமான சித்திரத்தை நமக்கு வழங்குகிறது.");

        // Set up button click listeners
        downloadButton.setOnClickListener(v -> {
            Toast.makeText(getContext(), "Download Clicked", Toast.LENGTH_SHORT).show();
            // Implement your download logic here
        });

        readButton.setOnClickListener(v -> {
            Toast.makeText(getContext(), "Read Clicked", Toast.LENGTH_SHORT).show();
            // Implement your read logic here (e.g., open a book reader activity)
        });

        // Use the modern way to handle back button press.
        // This addresses the "Code maturity" warning for onBackPressed().

        backButton.setOnClickListener(v ->{
                   Navigation.findNavController(getView()).popBackStack();
                });

        shareButton.setOnClickListener(v -> {
            Toast.makeText(getContext(), "Share Clicked", Toast.LENGTH_SHORT).show();
            // Implement share functionality
        });

        moreButton.setOnClickListener(v -> {
            Toast.makeText(getContext(),"More Clicked", Toast.LENGTH_SHORT).show();
            // Implement more options menu
        });

        bookmarkFab.setOnClickListener(v -> {
            Toast.makeText(getContext(), "Bookmark Clicked", Toast.LENGTH_SHORT).show();
            // Implement bookmark toggle logic
        });

        // Setup Tab Layout listener for handling tab changes
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                // Update descriptionText based on selected tab
                switch (tab.getPosition()) {
                    case 0: // Description tab
                        descriptionText.setText("கல்கி கிருஷ்ணமூர்த்தியின் “அலை ஓசை” நாவல், இரு பெரும் பாகங்களாகப் பிரிந்து, இந்திய சுதந்திரப் போராட்ட காலத்தின் சமூக மற்றும் அரசியல் பின்னணியில், மனித உறவுகளின் ஆழமான சித்திரத்தை நமக்கு வழங்குகிறது. ");
                        break;
                    case 1: // Reviews tab
                        descriptionText.setText("உலகப் புகழ்பெற்ற இயற்பியலாளர் ஸ்டீஃபன் ஹாக்கிங்கின் அரிய சொற்பொழிவுகளின் தொகுப்பாக “அனைத்திற்குமான கோட்பாடு” என்ற இந்த நூல் உங்கள் கைகளில் தவழ்கிறது.");
                        break;
                    case 2: // Suggestion tab
                        descriptionText.setText("உலகப் புகழ்பெற்ற இயற்பியலாளர் ஸ்டீஃபன் ஹாக்கிங்கின் அரிய சொற்பொழிவுகளின் தொகுப்பாக “அனைத்திற்குமான கோட்பாடு” என்ற இந்த நூல் உங்கள் கைகளில் தவழ்கிறது.");
                        break;
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                // Do nothing when a tab is unselected
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
                // Do nothing when a tab is reselected
            }
        });
        return view;
    }
}
