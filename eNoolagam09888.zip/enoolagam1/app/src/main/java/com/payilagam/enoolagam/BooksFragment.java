package com.payilagam.enoolagam;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.payilagam.enoolagam.model.BookModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class BooksFragment extends Fragment {

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private String mParam1;
    private String mParam2;

    public BooksFragment() {
        // Required empty public constructor
    }

    public static BooksFragment newInstance(String param1, String param2) {
        BooksFragment fragment = new BooksFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View booksView = inflater.inflate(R.layout.fragment_books, container, false);

        RecyclerView recyclerView = booksView.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new GridLayoutManager(getContext(), 2));

        ProgressBar progressBar = booksView.findViewById(R.id.progressBar);
        progressBar.setVisibility(View.VISIBLE);

        List<BookModel> books = new ArrayList<>();

        BookAdapter adapter = new BookAdapter(getContext(), books, book -> {
            NavController navController = Navigation.findNavController(booksView);
            navController.navigate(R.id.action_bookFragment_to_individualBookInfoFragment);
        });

        recyclerView.setAdapter(adapter);

        String booksUrl = "https://681ac79e17018fe50578b450.mockapi.io/api/books";

        RequestQueue networkQueue = Volley.newRequestQueue(requireContext());

        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(
                Request.Method.GET,
                booksUrl,
                null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        progressBar.setVisibility(View.GONE);

                        try {
                            books.clear();

                            for (int i = 0; i < response.length(); i++) {
                                JSONObject individualBook = response.getJSONObject(i);
                                books.add(new BookModel(
                                        individualBook.getString("author"),
                                        individualBook.getString("title"),
                                        121,
                                        120,
                                        individualBook.getString("image"),
                                        individualBook.optString("category", "Unknown") // ✅ Fix
                                ));
                                Log.d("book", "Loaded book #" + i);
                            }

                            adapter.notifyDataSetChanged();

                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(requireContext(), "Parsing error", Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        progressBar.setVisibility(View.GONE);
                        Toast.makeText(requireContext(), "Request Error", Toast.LENGTH_SHORT).show();
                        Log.e("VolleyError", error.toString());
                    }
                }
        );

        networkQueue.add(jsonArrayRequest);

        return booksView;
    }
}
