package com.payilagam.enoolagam;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.payilagam.enoolagam.model.BookModel;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class CategoryDetailActivity extends AppCompatActivity {

    public static final String CATEGORY_NAME_EXTRA = "CATEGORY_NAME";

    private TextView categoryTitleDetail;
    private RecyclerView detailRecyclerView;
    private BookAdapter detailAdapter;

    // This list should ideally come from a shared data source or be passed efficiently
    // For simplicity, we'll re-create dummy data here for demonstration.
    private List<BookModel> fullBookList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category_detail);

        categoryTitleDetail = findViewById(R.id.categoryTitleDetail);
        detailRecyclerView = findViewById(R.id.detailRecyclerView);

        // Get the category name passed from HomeFragment
        String category = getIntent().getStringExtra(CATEGORY_NAME_EXTRA);
        if (category == null || category.isEmpty()) {
            category = "All"; // Default to "All" if no category is passed
        }
        categoryTitleDetail.setText(category + " Books");

        // Setup dummy books (same as in HomeFragment for consistency)
        setupDummyBooks();

        // Filter books based on the received category
        List<BookModel> filteredBooks = filterBooksByCategory(category);

        // Setup RecyclerView for vertical grid display
        // 3 columns in a vertical grid
        detailRecyclerView.setLayoutManager(new GridLayoutManager(this, 3));
        detailAdapter = new BookAdapter(this, filteredBooks, book -> Toast.makeText(this, "Clicked: " + book.getBookName(), Toast.LENGTH_SHORT).show());
        detailRecyclerView.setAdapter(detailAdapter);
    }

    /**
     * Populates a dummy list of books. In a real app, this would come from a database or API.
     */
    private void setupDummyBooks() {
        fullBookList.clear();
        fullBookList.add(new BookModel("Author H1", "Scary Night 1", 120, 90, "https://example.com/horror1.jpg", "Horror"));
        fullBookList.add(new BookModel("Author H2", "Mystery Hill 2", 150, 80, "https://example.com/horror2.jpg", "Horror"));
        fullBookList.add(new BookModel("Author H3", "Haunted House 3", 130, 70, "https://example.com/horror3.jpg", "Horror"));
        fullBookList.add(new BookModel("Author H4", "Dark Forest 4", 140, 75, "https://example.com/horror4.jpg", "Horror"));
        fullBookList.add(new BookModel("Author H5", "Creepy Doll 5", 110, 65, "https://example.com/horror5.jpg", "Horror"));
        fullBookList.add(new BookModel("Author H6", "Zombie Apocalypse 6", 160, 95, "https://example.com/horror6.jpg", "Horror"));
        fullBookList.add(new BookModel("Author H7", "Vampire's Kiss 7", 170, 100, "https://example.com/horror7.jpg", "Horror"));
        fullBookList.add(new BookModel("Author H8", "Ghost Story 8", 125, 68, "https://example.com/horror8.jpg", "Horror"));

        fullBookList.add(new BookModel("Author R1", "Romantic Escape 1", 200, 130, "https://example.com/romance1.jpg", "Romance"));
        fullBookList.add(new BookModel("Author R2", "Love Letters 2", 170, 110, "https://example.com/romance2.jpg", "Romance"));
        fullBookList.add(new BookModel("Author R3", "First Date 3", 160, 100, "https://example.com/romance3.jpg", "Romance"));
        fullBookList.add(new BookModel("Author R4", "Eternal Embrace 4", 180, 120, "https://example.com/romance4.jpg", "Romance"));
        fullBookList.add(new BookModel("Author R5", "Star-Crossed 5", 190, 125, "https://example.com/romance5.jpg", "Romance"));
        fullBookList.add(new BookModel("Author R6", "Sweet Serenade 6", 155, 98, "https://example.com/romance6.jpg", "Romance"));
        fullBookList.add(new BookModel("Author R7", "Moonlit Dance 7", 165, 105, "https://example.com/romance7.jpg", "Romance"));

        fullBookList.add(new BookModel("Author O1", "Generic Book 1", 100, 60, "https://example.com/book1.jpg", "Others"));
        fullBookList.add(new BookModel("Author O2", "Fantasy Realm 2", 140, 85, "https://example.com/book2.jpg", "Others"));
        fullBookList.add(new BookModel("Author O3", "Sci-Fi Saga 3", 180, 115, "https://example.com/book3.jpg", "Others"));
        fullBookList.add(new BookModel("Author O4", "Adventure Quest 4", 135, 78, "https://example.com/book4.jpg", "Others"));
    }

    /**
     * Filters the full book list based on the provided category.
     */
    private List<BookModel> filterBooksByCategory(String category) {
        if (category.equalsIgnoreCase("All")) {
            return new ArrayList<>(fullBookList); // Return a copy of all books
        } else {
            return fullBookList.stream()
                    .filter(book -> book.getCategory().equalsIgnoreCase(category))
                    .collect(Collectors.toList());
        }
    }
}