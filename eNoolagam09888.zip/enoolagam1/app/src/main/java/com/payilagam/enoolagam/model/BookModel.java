package com.payilagam.enoolagam.model;

public class BookModel {
    private String bookName;
    private String author;
    private int totalPages;
    private int likes;
    private String bookCover;
    private String category; // ✅ New field for category

    public BookModel(String author, String bookName, int totalPages, int likes, String bookCover, String category) {
        this.author = author;
        this.bookName = bookName;
        this.totalPages = totalPages;
        this.likes = likes;
        this.bookCover = bookCover;
        this.category = category;
    }

    // ✅ Getters and Setters
    public String getBookName() {
        return bookName;
    }

    public void setBookName(String bookName) {
        this.bookName = bookName;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public int getTotalPages() {
        return totalPages;
    }

    public void setTotalPages(int totalPages) {
        this.totalPages = totalPages;
    }

    public int getLikes() {
        return likes;
    }

    public void setLikes(int likes) {
        this.likes = likes;
    }

    public String getBookCover() {
        return bookCover;
    }

    public void setBookCover(String bookCover) {
        this.bookCover = bookCover;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }
}
