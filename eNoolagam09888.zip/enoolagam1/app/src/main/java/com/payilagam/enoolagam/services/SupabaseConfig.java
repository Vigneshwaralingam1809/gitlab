package com.payilagam.enoolagam.services;

public class SupabaseConfig {
    public static final String SUPABASE_URL = "https://jcrpcmsmuiayfkqmwklo.supabase.co";
    public static final String SUPABASE_API_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImpjcnBjbXNtdWlheWZrcW13a2xvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTQzNzMxNjIsImV4cCI6MjA2OTk0OTE2Mn0.i2p83riYpQ2IaxkIUnUEqlK6qDVpcuVCdEeAmqqn01o";
}
