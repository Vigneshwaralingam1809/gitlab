package com.payilagam.enoolagam;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.material.textfield.TextInputEditText;

public class LoginActivity extends AppCompatActivity {

    private TextInputEditText etEmail;
    private TextInputEditText etPassword;
    private Button btnLogin;
    private TextView tvRegister;
    private TextView tvForgotPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login); // Make sure this is the correct layout file name

        // Initialize the views. Note that we are now casting to the correct type.
        // The IDs match the updated XML layout.
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        tvRegister = findViewById(R.id.tvRegister);
        tvForgotPassword = findViewById(R.id.tvForgotPassword);

        // Set a click listener for the Login button
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = etEmail.getText().toString().trim();
                String password = etPassword.getText().toString().trim();

                // Basic validation
                if (email.isEmpty() || password.isEmpty()) {
                    Toast.makeText(LoginActivity.this, "Please enter email and password", Toast.LENGTH_SHORT).show();
                } else {
                    // TODO: Implement your actual login logic here
                    Toast.makeText(LoginActivity.this, "Login successful for " + email, Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Set a click listener for the Register link
        tvRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO: Implement navigation to the registration screen here
                Toast.makeText(LoginActivity.this, "Navigate to Register Screen", Toast.LENGTH_SHORT).show();
            }
        });

        // Set a click listener for the Forgot Password link
        tvForgotPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO: Implement navigation to the forgot password screen here
                Toast.makeText(LoginActivity.this, "Navigate to Forgot Password Screen", Toast.LENGTH_SHORT).show();
            }
        });
    }
}