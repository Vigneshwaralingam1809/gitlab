package com.payilagam.enoolagam.services;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONObject;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;

public class SupabaseClient {

    private static final String SUPABASE_URL = "https://diwtblmznvqmgmbvkzyg.supabase.co"; // Replace
    private static final String SUPABASE_API_KEY = "sb_publishable_WeA9MXrroGTyEBBsS1eJgk_gBW0EqRnF"; // Replace

    public interface SupabaseLoginCallback {
        void onSuccess(String response);
        void onFailure(String error);
    }

    public static void registerUser(Context context, String email, String password, SupabaseLoginCallback callback) {
        new Thread(() -> {
            try {
                URL url = new URL(SUPABASE_URL + "/auth/v1/signup");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("apikey", SUPABASE_API_KEY);
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setDoOutput(true);

                String jsonBody = new JSONObject()
                        .put("email", email)
                        .put("password", password)
                        .toString();

                try (OutputStream os = conn.getOutputStream()) {
                    os.write(jsonBody.getBytes());
                }

                int responseCode = conn.getResponseCode();
                Scanner scanner = new Scanner(conn.getInputStream()).useDelimiter("\\A");
                String response = scanner.hasNext() ? scanner.next() : "";

                new Handler(Looper.getMainLooper()).post(() -> {
                    if (responseCode == 200 || responseCode == 201) {
                        callback.onSuccess("Registered successfully.");
                    } else {
                        callback.onFailure("Registration failed: " + response);
                    }
                });

            } catch (Exception e) {
                new Handler(Looper.getMainLooper()).post(() -> {
                    callback.onFailure("Error: " + e.getMessage());
                });
            }
        }).start();
    }

    public static void loginUser(Context context, String email, String password, SupabaseLoginCallback callback) {
        new Thread(() -> {
            try {
                URL url = new URL(SUPABASE_URL + "/auth/v1/token?grant_type=password");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("apikey", SUPABASE_API_KEY);
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setDoOutput(true);

                String jsonBody = new JSONObject()
                        .put("email", email)
                        .put("password", password)
                        .toString();

                try (OutputStream os = conn.getOutputStream()) {
                    os.write(jsonBody.getBytes());
                }

                int responseCode = conn.getResponseCode();
                Scanner scanner = new Scanner(conn.getInputStream()).useDelimiter("\\A");
                String response = scanner.hasNext() ? scanner.next() : "";

                new Handler(Looper.getMainLooper()).post(() -> {
                    if (responseCode == 200) {
                        callback.onSuccess("Login successful!");
                    } else {
                        callback.onFailure("Login failed: " + response);
                    }
                });

            } catch (Exception e) {
                new Handler(Looper.getMainLooper()).post(() -> {
                    callback.onFailure("Error: " + e.getMessage());
                });
            }
        }).start();
    }
}
