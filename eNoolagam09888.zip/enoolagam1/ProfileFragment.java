package com.payilagam.enoolagam;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import androidx.fragment.app.Fragment;

public class ProfileFragment extends Fragment {

    private Button btnLogout;
    @Override
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup container,Bundle savedInstance){
        View view = layoutInflater.inflate(R.layout.fragment_profile, container, false);
        btnLogout = view.findViewById(R.id.btnlogout);
        btnLogout.setOnClickListener(v->{
            AuthManager.clearAuthInfo(getContext());
            Intent loginIndent = new Intent(getContext(), LoginActivity.class);
            loginIndent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(loginIndent);
        });
        return view;
    }

}
